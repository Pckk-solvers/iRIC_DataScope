# Case1.cgn 調査メモ (2026-02-20)

## 対象
- 入力ファイル: `C:\Users\yuuta.ochiai\Downloads\Case1.cgn`
- 発生エラー: `Unable to synchronously open object (addr overflow, addr = 10725326, size = 80, eoa = 10725086)`

## 結論
- `Case1.cgn` は **HDF5 ヘッダ整合性不良**（EOF/EOA 不一致）を含む。
- EOF を修正すると一部読めるが、iRIC_DataScope が必要とする結果構造（`GridCoordinates` / `FlowSolutionPointers` など）は欠落しており、通常解析は不可。
- 取得できたのは `iRIC/iRICZone` 直下の 4 配列のみ（時系列ではない）。

## 重要注意
- `Case1_eofpatch.cgn` は EOF ヘッダ値を補正した **診断用ファイル**。
- これは「元ファイルの完全修復」ではなく、構造欠落（`GridCoordinates` など）は残る。
- よって iRIC_DataScope や通常の時系列解析に使える保証はない。
- 共有パックの容量を抑えるため、本フォルダには `Case1_eofpatch.cgn` 本体を同梱していない。

## 主要事実
- 実ファイルサイズ: `2,389,546,051 bytes`
- HDF5 superblock (v0) の `eof_addr`: `10,725,086`
- `eof_addr != 実ファイルサイズ` のため、HDF5 が「有効なファイル終端」を誤認し `addr overflow` を起こす。

## 実施した検証
1. `h5py` で `Case1.cgn` を開く
- root は列挙可能（`format`, `hdf5version`, `CGNSLibraryVersion`, `iRIC`）
- `iRIC` グループを開く段階で `addr overflow`

2. EOF パッチ版作成 (`Case1_eofpatch.cgn`)
- superblock の `eof_addr` を実ファイルサイズへ合わせる
- これにより `iRIC` / `iRICZone` へ到達可能

3. 構造確認（パッチ版）
- `iRIC/iRICZone` 直下: `term_advc_x`, `term_fric_x`, `qq_iface`, `ebcx_height` のみ
- 欠落: `iRIC/iRICZone/GridCoordinates/CoordinateX`, `CoordinateY`, `ZoneIterativeData/FlowSolutionPointers`, `FlowSolution*`
- `iRIC/BaseIterativeData/ data` は `[0]` のみ（時刻系列情報として不十分）

## 抽出できた配列
出力先: `zone_export_case1_eofpatch`
- `ebcx_height` (`72 x 813`)
- `qq_iface` (`72 x 813`)
- `term_advc_x` (`72 x 813`)
- `term_fric_x` (`72 x 813`)

## 「容量は正常なのに壊れる」理由
- HDF5/CGNS は「サイズ」だけでなく「内部参照テーブル（メタデータ）」で読む。
- 容量が正常でも、EOF/参照情報が壊れると読み込み不能になる。
- 今回はまさにそのパターン（実サイズとヘッダ終端値が乖離）。

## 先方説明用の要約案
- 「iRIC の出力 CGNS に対し、HDF5 レベルで内部終端情報（EOF/EOA）の不整合が検出されました。容量は正常に見えるものの、内部参照が壊れているため `addr overflow` で読み込めません。EOF 修正で一部読める状態にはなりましたが、解析に必要な `GridCoordinates` / `FlowSolution` 系ノードが欠落しており、時系列結果としては利用できません。」

## 再現・補助スクリプト
- 整合性診断: `analyze_cgn_integrity.py`
- 配列書き出し: `export_zone_arrays.py`

前提:
- Python `3.13` 推奨（`3.10+` でも概ね可）
- 必要ライブラリ: `h5py`, `numpy`
- `uv` 利用時は `uv run --with h5py --with numpy python ...` で実行可能

例:
```powershell
uv run --with h5py --with numpy python .\analyze_cgn_integrity.py "C:\Users\yuuta.ochiai\Downloads\Case1.cgn" --extract-zone --out ".\Case1.integrity.with_zone.json"
uv run --with h5py --with numpy python .\analyze_cgn_integrity.py "C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn" --extract-zone --out ".\Case1_eofpatch.integrity.with_zone.json"
uv run --with h5py --with numpy python .\export_zone_arrays.py "C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn" --out-dir ".\zone_export_case1_eofpatch"
```

`uv` 非利用時:
```powershell
pip install h5py numpy
python .\analyze_cgn_integrity.py ".\Case1.cgn" --extract-zone --out ".\Case1.integrity.with_zone.json"
python .\analyze_cgn_integrity.py "C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn" --extract-zone --out ".\Case1_eofpatch.integrity.with_zone.json"
python .\export_zone_arrays.py "C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn" --out-dir ".\zone_export_case1_eofpatch"
```

## 生成済みレポート
- `Case1.integrity.json`
- `Case1.integrity.with_zone.json`
- `Case1_eofpatch.integrity.with_zone.json`
- `zone_export_case1_eofpatch/manifest.json`

## 事象仮説（先方への確認ポイント）
- 計算結果出力の途中で異常終了し、HDF5 メタデータ更新が完了しなかった可能性。
- その結果、ファイル容量は正常に見えても、内部参照（EOF/EOA やノード構造）が破損し得る。
