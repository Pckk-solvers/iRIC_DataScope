# Case1.cgn 調査共有パック

## 目的
- iRIC 技術者へ共有するため、`Case1.cgn` の障害調査内容を1フォルダに集約。

## 主要結論
- 元ファイル `Case1.cgn` は HDF5 ヘッダの EOF/EOA 不整合があり、`addr overflow` で `iRIC` グループが開けない。
- EOF を実ファイルサイズに合わせたパッチ版では `iRIC` グループに到達可能。
- ただし、通常解析に必要な `GridCoordinates` / `FlowSolutionPointers` / `FlowSolution*` が欠落し、時系列としては利用不可。
- 抽出できたのは `iRIC/iRICZone/*/ data` の4配列のみ。
- `Case1_eofpatch.cgn` は診断用の補助ファイルであり、通常解析へ復旧できたことを意味しない（容量削減のため本共有パックには含めない）。

## 同梱ファイル
- `Case1-cgn-investigation-2026-02-20.md`
  - 調査の詳細メモ（背景・根拠・説明文）
- `analyze_cgn_integrity.py`
  - CGNS/HDF5 整合性診断スクリプト
- `export_zone_arrays.py`
  - `iRIC/iRICZone/*/ data` を CSV/NPY に書き出すスクリプト
- `requirements.txt`
  - 最小依存（`h5py`, `numpy`）
- `Case1.integrity.json`
  - 元ファイルの診断結果
- `Case1.integrity.with_zone.json`
  - 元ファイルのゾーン抽出込み診断結果
- `Case1_eofpatch.integrity.with_zone.json`
  - EOF パッチ版ファイルの診断結果
- `zone_export_case1_eofpatch/`
  - 抽出できた4配列の CSV/NPY と `manifest.json`

## 実行環境
- 推奨 Python: `3.13`（`3.10+` でも概ね可）
- 必要ライブラリ（この調査スクリプトで使用）:
  - `h5py`
  - `numpy`
- `uv` を使う場合:
  - このフォルダで `uv run --with h5py --with numpy python ...` を実行
- `uv` を使わない場合:
  - 任意の仮想環境で `pip install h5py numpy`
  - その後に `python ...` で実行

## 実行例（再現）
```powershell
uv run --with h5py --with numpy python .\analyze_cgn_integrity.py "C:\Users\yuuta.ochiai\Downloads\Case1.cgn" --extract-zone --out ".\Case1.integrity.with_zone.json"
uv run --with h5py --with numpy python .\analyze_cgn_integrity.py "C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn" --extract-zone --out ".\Case1_eofpatch.integrity.with_zone.json"
uv run --with h5py --with numpy python .\export_zone_arrays.py "C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn" --out-dir ".\zone_export_case1_eofpatch"
```

`uv` なしの同等コマンド:
```powershell
python .\analyze_cgn_integrity.py ".\Case1.cgn" --extract-zone --out ".\Case1.integrity.with_zone.json"
python .\analyze_cgn_integrity.py "C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn" --extract-zone --out ".\Case1_eofpatch.integrity.with_zone.json"
python .\export_zone_arrays.py "C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn" --out-dir ".\zone_export_case1_eofpatch"
```

## 元データ位置（参考）
- 元ファイル: `C:\Users\yuuta.ochiai\Downloads\Case1.cgn`
- EOF パッチ版: `C:\Users\yuuta.ochiai\Downloads\Case1_eofpatch.cgn`
